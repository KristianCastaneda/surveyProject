# todoApp

A sample todo application built with the MEAN stack.
