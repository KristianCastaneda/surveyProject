// Database URL
module.exports = {
    // Uncomment to connect with MongoDB on Cloud
    // 'url' : 'mongodb://admin:admin@ds053251.mongolab.com:53251/todoapp'
    'url' : 'mongodb://admin:admin@ds061671.mongolab.com:61671/heroku_app35644233'
};